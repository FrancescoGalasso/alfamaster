--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.14
-- Dumped by pg_dump version 9.5.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO admin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO admin;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO admin;

--
-- Name: product_product; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.product_product (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    name character varying(25) NOT NULL,
    data jsonb NOT NULL,
    owner character varying(25) NOT NULL,
    revision integer NOT NULL
);


ALTER TABLE public.product_product OWNER TO admin;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.product_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_product_id_seq OWNER TO admin;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product_product.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_product ALTER COLUMN id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add product	7	add_product
20	Can change product	7	change_product
21	Can delete product	7	delete_product
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 21, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$36000$wCHgM1zCB7d1$HOjSFTSXarLU2qUUFuL9e8e40o53h5jwUCtigs9ch7A=	2018-10-01 09:08:51.755028+02	t	galasso				t	t	2018-07-26 13:23:05.322148+02
2	pbkdf2_sha256$36000$K5Bemeshyn2K$A0AV+dDh/Owq3TGY+n8Dv8wIZHmwLUfijYP0mg93gjo=	2018-11-12 08:27:31.160238+01	t	admin				t	t	2018-09-27 10:32:14.915946+02
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2018-07-26 13:24:17.384563+02	1	lavabile	1	Added.	7	1
2	2018-07-26 14:04:41.15083+02	2	interni	1	Added.	7	1
3	2018-07-26 16:59:34.144453+02	2	interni	2	Changed data.	7	1
4	2018-07-26 17:00:22.053908+02	1	lavabile	2	Changed data.	7	1
5	2018-07-26 17:41:24.711493+02	2	interni	2	Changed data.	7	1
6	2018-07-27 09:04:48.244501+02	1	lavabile	2	Changed data.	7	1
7	2018-07-31 12:22:39.915443+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
8	2018-07-31 12:31:00.897209+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
9	2018-07-31 14:16:55.586475+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
10	2018-07-31 17:57:44.05403+02	3	test	1	[{"added": {}}]	7	1
11	2018-08-02 09:07:12.412722+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
12	2018-08-02 09:26:07.753917+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
13	2018-08-02 09:44:14.323501+02	3	test	2	[]	7	1
14	2018-08-02 10:40:09.277974+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
15	2018-08-02 10:50:54.37301+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
16	2018-08-02 10:59:18.530022+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
17	2018-08-02 11:02:23.967682+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
18	2018-08-02 11:54:48.632372+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
19	2018-08-02 14:47:18.744637+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
20	2018-08-02 14:49:08.926808+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
21	2018-08-02 15:48:09.069069+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
22	2018-08-02 16:25:03.216373+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
23	2018-08-07 10:37:39.538772+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
24	2018-08-07 12:15:45.703153+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
25	2018-08-07 12:27:45.345142+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
26	2018-08-07 12:33:03.724979+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
27	2018-08-07 12:33:09.827256+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
28	2018-08-10 16:01:03.342228+02	4	test2	1	[{"added": {}}]	7	1
29	2018-08-27 17:49:59.122581+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
30	2018-08-27 17:50:58.599379+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
31	2018-08-28 09:19:53.981578+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
32	2018-08-28 09:21:17.796178+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
33	2018-08-28 09:23:04.456918+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
34	2018-08-28 09:23:29.088582+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
35	2018-08-28 09:24:29.31791+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
36	2018-08-28 09:28:04.781438+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
37	2018-08-28 10:18:36.578364+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
38	2018-08-28 10:20:40.475454+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
39	2018-08-28 10:22:26.883145+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
40	2018-08-28 11:56:10.917546+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
41	2018-08-28 14:17:47.228619+02	4	test_wrong_data	2	[{"changed": {"fields": ["name"]}}]	7	1
42	2018-08-28 14:48:15.620281+02	3	test	2	[{"changed": {"fields": ["data"]}}]	7	1
43	2018-08-30 12:48:21.537606+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
44	2018-08-30 13:54:18.481863+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
45	2018-08-30 14:35:37.757344+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
46	2018-08-30 14:43:08.226019+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
47	2018-08-30 14:59:00.895847+02	1	lavabile	2	[{"changed": {"fields": ["data"]}}]	7	1
48	2018-09-03 17:22:43.111282+02	2	interni	2	[{"changed": {"fields": ["data"]}}]	7	1
49	2018-09-04 10:25:13.57741+02	5	test3	1	[{"added": {}}]	7	1
50	2018-09-12 08:50:36.082062+02	6	test4	1	[{"added": {}}]	7	1
51	2018-09-27 10:33:25.632308+02	1	galasso	2	[{"changed": {"fields": ["password"]}}]	4	2
52	2018-09-27 11:32:36.241165+02	7	test5	1	[{"added": {}}]	7	2
53	2018-10-01 12:10:05.543719+02	9	saved_from_form	3		7	1
54	2018-10-01 12:10:15.404824+02	8	saved_from_form	3		7	1
55	2018-10-01 12:22:11.111712+02	14	saved_from_form3	3		7	1
56	2018-10-01 12:22:11.122626+02	13	saved_from_form3	3		7	1
57	2018-10-01 12:22:11.124722+02	12	saved_from_form3	3		7	1
58	2018-10-01 12:22:11.126755+02	11	saved_from_form2	3		7	1
59	2018-10-01 12:22:11.128891+02	10	saved_from_form	3		7	1
60	2018-10-01 15:38:55.724709+02	17	saved_from_form	3		7	1
61	2018-10-01 15:38:55.73312+02	16	saved_from_form	3		7	1
62	2018-10-01 15:38:55.736079+02	15	saved_from_form	3		7	1
63	2018-10-11 17:51:27.251574+02	22	123123	3		7	2
64	2018-10-11 17:51:27.26316+02	21	test3	3		7	2
65	2018-10-11 17:57:14.689958+02	24	My js test value	3		7	2
66	2018-10-11 18:01:00.636473+02	26	{"data":"pluto"}	3		7	2
67	2018-10-11 18:01:00.645888+02	25	My js test value	3		7	2
68	2018-10-11 18:01:00.648638+02	23	123123	3		7	2
69	2018-10-11 18:01:51.18721+02	28	My js test value	3		7	2
70	2018-10-11 18:01:51.196261+02	27	{"data":"pluto"}	3		7	2
71	2018-10-12 08:45:46.664155+02	30	My js test value	3		7	2
72	2018-10-12 08:45:46.673679+02	29	My js test value	3		7	2
73	2018-10-12 09:08:38.333128+02	31	My js test value	3		7	2
74	2018-10-12 09:10:13.338194+02	32	My js test value	3		7	2
75	2018-10-12 09:10:42.445704+02	19	saved_from_form3	3		7	2
76	2018-10-12 09:10:42.455582+02	18	saved_from_form	3		7	2
77	2018-10-12 09:10:42.458702+02	7	test5	3		7	2
78	2018-10-12 09:10:42.465065+02	6	test4	3		7	2
79	2018-10-12 09:10:42.469254+02	5	test3	3		7	2
80	2018-10-12 09:28:39.803982+02	34	My js test value	3		7	2
81	2018-10-12 09:28:39.815035+02	33	My js test value	3		7	2
82	2018-10-12 09:35:16.339218+02	36	My js test value	3		7	2
83	2018-10-12 09:35:16.348205+02	35	My js test value	3		7	2
84	2018-10-12 09:48:59.913224+02	38	My js test value	3		7	2
85	2018-10-12 09:48:59.925389+02	37	My js test value	3		7	2
86	2018-10-12 09:51:18.903477+02	40	My js test value	3		7	2
87	2018-10-12 09:51:18.912028+02	39	My js test value	3		7	2
88	2018-10-12 09:59:50.442185+02	41	My js test value	3		7	2
89	2018-10-12 10:36:28.126549+02	42	My js test value	3		7	2
90	2018-10-12 10:44:57.469929+02	43	My js test value	3		7	2
91	2018-10-12 10:56:12.401014+02	44	My js test value	3		7	2
92	2018-10-23 10:39:04.229892+02	65	My js test value	3		7	2
93	2018-10-23 10:39:04.241813+02	54	My js test value	3		7	2
94	2018-10-23 15:58:43.960457+02	4	test_wrong_data	3		7	2
95	2018-10-23 15:58:43.978091+02	3	test	3		7	2
96	2018-10-23 15:58:43.981114+02	2	interni	3		7	2
97	2018-10-26 17:15:13.850565+02	82		3		7	2
98	2018-10-26 17:15:13.863064+02	80		3		7	2
99	2018-11-05 17:13:54.052756+01	85		3		7	2
100	2018-11-06 10:30:05.851878+01	87	test	3		7	2
101	2018-11-06 11:35:03.642296+01	88	test	3		7	2
102	2018-11-07 11:28:16.822363+01	92	test 5rm 3b	3		7	2
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 102, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	product	product
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 7, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-07-26 13:22:52.709932+02
2	auth	0001_initial	2018-07-26 13:22:52.841758+02
3	admin	0001_initial	2018-07-26 13:22:52.886629+02
4	admin	0002_logentry_remove_auto_add	2018-07-26 13:22:52.900723+02
5	contenttypes	0002_remove_content_type_name	2018-07-26 13:22:52.937057+02
6	auth	0002_alter_permission_name_max_length	2018-07-26 13:22:52.952545+02
7	auth	0003_alter_user_email_max_length	2018-07-26 13:22:52.973442+02
8	auth	0004_alter_user_username_opts	2018-07-26 13:22:52.989658+02
9	auth	0005_alter_user_last_login_null	2018-07-26 13:22:53.001818+02
10	auth	0006_require_contenttypes_0002	2018-07-26 13:22:53.005333+02
11	auth	0007_alter_validators_add_error_messages	2018-07-26 13:22:53.014448+02
12	product	0001_initial	2018-07-26 13:22:53.049263+02
13	product	0002_auto_20180726_1322	2018-07-26 13:22:53.173354+02
14	sessions	0001_initial	2018-07-26 13:22:53.195803+02
15	auth	0008_alter_user_username_max_length	2018-07-30 11:29:59.604303+02
16	product	0003_auto_20181022_1713	2018-10-22 17:14:48.366826+02
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 16, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
ba78olnwoiavmcu8v0a3uke8hows6ep9	YjRlMzU1ZGViYTUyMTJmNzBkMjJhNTFlOGIwOGI1NjQ0OWMzMjU0NTp7Il9hdXRoX3VzZXJfaGFzaCI6ImE0MjA5ODM0NDg2YzY1NDUyMWFlNjI1NDBlNDMyNzkxNTNhNDQ0YTUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-08-09 13:23:19.827807+02
ks1ozukrgj2903six6an4ml1ahj7vr0h	NzZlYmZjM2M4M2I0Y2QwY2ZhMmE2YmNhYjJhMGRmYzUzY2VhYTkwNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNiZWEwNDgyYjVjNjVhNWY2OWE2YmMxMzRlZmVhNzhmOTJjYzM5YTIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-08-14 11:49:04.801042+02
770w6zvtad7e2itk11em1epoqvhsb48a	NzZlYmZjM2M4M2I0Y2QwY2ZhMmE2YmNhYjJhMGRmYzUzY2VhYTkwNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNiZWEwNDgyYjVjNjVhNWY2OWE2YmMxMzRlZmVhNzhmOTJjYzM5YTIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-08-24 14:38:47.0265+02
k5ucwib3su7ewuf7c1mlw1z6bernidmo	NzZlYmZjM2M4M2I0Y2QwY2ZhMmE2YmNhYjJhMGRmYzUzY2VhYTkwNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNiZWEwNDgyYjVjNjVhNWY2OWE2YmMxMzRlZmVhNzhmOTJjYzM5YTIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-09-10 17:20:04.255336+02
1rjs1rtad6i7jggt0lo0mrpzyc34vujc	NzZlYmZjM2M4M2I0Y2QwY2ZhMmE2YmNhYjJhMGRmYzUzY2VhYTkwNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNiZWEwNDgyYjVjNjVhNWY2OWE2YmMxMzRlZmVhNzhmOTJjYzM5YTIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-09-26 08:39:36.80526+02
yo3re3vcuad7vfzws3mbx9rcx9pog1m1	MDczMDU0YzIzZjBmMGZhYzExNGQyMjgzNDYyMTgzNWJiM2E5OWJkODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ2MGU3Yjk4NzI0NmJiMWM4NmNlMWY5OTQxOGQ4MjY5NjFiNzY4YTQiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2018-10-11 10:33:25.646223+02
uu0bxu9k53w878yc8oxwtrt1chijk83v	ZDJlNzFjODk0NzRiNDYxZjRiOTY5NzQ4Y2RmMTk2NzE2NzcyOTk1Zjp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ2MGU3Yjk4NzI0NmJiMWM4NmNlMWY5OTQxOGQ4MjY5NjFiNzY4YTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2018-10-11 18:22:58.283131+02
60oxr7d3eq0q27ewaalardznjespucfx	NGZkYjA3MmE1OTNlZmM2MzU0ZDU3MmExNGMwMGM4YTkxOWM3NjM3ODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhkZDZmMWU2MjQ1YzUxMTlhZDk4YzI2ZDJkNTI5ZWMwMzYzOWE0NTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-10-15 09:08:51.760186+02
gbdegrg1gf1m8zxkadhovgeh9m2cl40i	ZDJlNzFjODk0NzRiNDYxZjRiOTY5NzQ4Y2RmMTk2NzE2NzcyOTk1Zjp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ2MGU3Yjk4NzI0NmJiMWM4NmNlMWY5OTQxOGQ4MjY5NjFiNzY4YTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2018-10-25 17:51:13.324463+02
bw8711qtbjeufwqfgt9r998jwwvrexlv	ZDJlNzFjODk0NzRiNDYxZjRiOTY5NzQ4Y2RmMTk2NzE2NzcyOTk1Zjp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ2MGU3Yjk4NzI0NmJiMWM4NmNlMWY5OTQxOGQ4MjY5NjFiNzY4YTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2018-11-09 16:15:03.414031+01
2bxbkpi2tjqwdknp0x3i0udqmd3avr8p	ZDJlNzFjODk0NzRiNDYxZjRiOTY5NzQ4Y2RmMTk2NzE2NzcyOTk1Zjp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ2MGU3Yjk4NzI0NmJiMWM4NmNlMWY5OTQxOGQ4MjY5NjFiNzY4YTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2018-11-26 08:27:31.169999+01
\.


--
-- Data for Name: product_product; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.product_product (id, created_date, name, data, owner, revision) FROM stdin;
66	2018-10-22 17:16:52.374446+02	My js test value	{"data": [{"bases": [{"g_100g": "25", "v_100v": "36.96", "ml_100g": "25.000", "ml_1000ml": "369.60", "formula_cost": "0.0000"}, {"g_100g": "5", "v_100v": "11.51", "ml_100g": "5.000", "ml_1000ml": "115.10", "formula_cost": "0.0000"}], "RM_cost": "0", "raw_material": "H<sub>2</sub>O", "specific_weight": "1"}, {"bases": [{"g_100g": "40", "v_100v": "55.26", "ml_100g": "37.383", "ml_1000ml": "552.60", "formula_cost": "0.1094"}, {"g_100g": "20", "v_100v": "43.04", "ml_100g": "18.692", "ml_1000ml": "430.40", "formula_cost": "0.0852"}], "RM_cost": "1.85", "raw_material": "Binder", "specific_weight": "1.07"}, {"bases": [{"g_100g": "20", "v_100v": "7.78", "ml_100g": "5.263", "ml_1000ml": "77.80", "formula_cost": "0.0961"}, {"g_100g": "75", "v_100v": "45.45", "ml_100g": "19.737", "ml_1000ml": "454.50", "formula_cost": "0.5613"}], "RM_cost": "3.25", "raw_material": "TiO<sub>2</sub>", "specific_weight": "3.8"}]}		1
70	2018-10-23 10:15:34.414509+02	My js test value	{"data": [{"bases": [{"g_100g": "25", "v_100v": "34.92", "ml_100g": "25.000", "ml_1000ml": "349.20", "formula_cost": "0.0000"}, {"g_100g": "5", "v_100v": "11.51", "ml_100g": "5.000", "ml_1000ml": "115.10", "formula_cost": "0.0000"}], "RM_cost": "0", "raw_material": "H<sub>2</sub>O", "specific_weight": "1"}, {"bases": [{"g_100g": "40", "v_100v": "52.22", "ml_100g": "37.383", "ml_1000ml": "522.20", "formula_cost": "0.1034"}, {"g_100g": "20", "v_100v": "43.04", "ml_100g": "18.692", "ml_1000ml": "430.40", "formula_cost": "0.0852"}], "RM_cost": "1.85", "raw_material": "Binder", "specific_weight": "1.07"}, {"bases": [{"g_100g": "35", "v_100v": "12.87", "ml_100g": "9.211", "ml_1000ml": "128.70", "formula_cost": "0.1609"}, {"g_100g": "75", "v_100v": "45.45", "ml_100g": "19.737", "ml_1000ml": "454.50", "formula_cost": "0.5682"}], "RM_cost": "3.29", "raw_material": "TiO<sub>2</sub>", "specific_weight": "3.8"}]}		2
71	2018-10-23 15:39:33.546044+02	My js test value	{"data": [{"bases": [{"g_100g": "25", "v_100v": "34.92", "ml_100g": "25.000", "ml_1000ml": "349.20", "formula_cost": "0.0000"}, {"g_100g": "5", "v_100v": "11.51", "ml_100g": "5.000", "ml_1000ml": "115.10", "formula_cost": "0.0000"}], "RM_cost": "0", "raw_material": "H<sub>2</sub>O", "specific_weight": "1"}, {"bases": [{"g_100g": "40", "v_100v": "52.22", "ml_100g": "37.383", "ml_1000ml": "522.20", "formula_cost": "0.1034"}, {"g_100g": "20", "v_100v": "43.04", "ml_100g": "18.692", "ml_1000ml": "430.40", "formula_cost": "0.0852"}], "RM_cost": "1.85", "raw_material": "Binder", "specific_weight": "1.07"}, {"bases": [{"g_100g": "35", "v_100v": "12.87", "ml_100g": "9.211", "ml_1000ml": "128.70", "formula_cost": "0.1658"}, {"g_100g": "75", "v_100v": "45.45", "ml_100g": "19.737", "ml_1000ml": "454.50", "formula_cost": "0.5855"}], "RM_cost": "3.39", "raw_material": "TiO<sub>2</sub>", "specific_weight": "3.8"}]}		3
75	2018-10-23 16:11:07.899273+02	My js test value 2	{"data": [{"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}]}		1
76	2018-10-23 16:13:19.242335+02	My js test value 2	{"data": [{"bases": [{"g_100g": "8", "v_100v": "32.15", "ml_100g": "1.000", "ml_1000ml": "321.50", "formula_cost": "2.0576"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "32.15", "ml_100g": "1.000", "ml_1000ml": "321.50", "formula_cost": "2.0576"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "8"}, {"bases": [{"g_100g": "8.88", "v_100v": "35.69", "ml_100g": "1.110", "ml_1000ml": "356.90", "formula_cost": "2.2842"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}]}		2
77	2018-10-24 09:26:17.862065+02	My js test value 2	{"data": [{"bases": [{"g_100g": "8", "v_100v": "32.05", "ml_100g": "1.000", "ml_1000ml": "320.50", "formula_cost": "2.0512"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "32.05", "ml_100g": "1.000", "ml_1000ml": "320.50", "formula_cost": "2.0512"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "8"}, {"bases": [{"g_100g": "8.963", "v_100v": "35.90", "ml_100g": "1.120", "ml_1000ml": "359.00", "formula_cost": "2.2976"}, {"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}]}		3
78	2018-10-24 12:22:42.104372+02	My js test value	{"data": [{"bases": [{"g_100g": "89", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "264.0069"}, {"g_100g": "89", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "264.0069"}], "RM_cost": "89", "raw_material": "H<sub>2</sub>O", "specific_weight": "89"}, {"bases": [{"g_100g": "89", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "264.0069"}, {"g_100g": "89", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "264.0069"}], "RM_cost": "89", "raw_material": "Binder", "specific_weight": "89"}, {"bases": [{"g_100g": "89", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "264.0069"}, {"g_100g": "89", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "264.0069"}], "RM_cost": "89", "raw_material": "TiO<sub>2</sub>", "specific_weight": "89"}]}		0
84	2018-10-31 11:51:41.892356+01	first suggestions	{"data": [{"bases": [{"g_100g": "25", "v_100v": "36.96", "ml_100g": "25.000", "ml_1000ml": "369.60", "formula_cost": "0.0000"}, {"g_100g": "0", "v_100v": "0.00", "ml_100g": "0.000", "ml_1000ml": "0.00", "formula_cost": "0.0000"}], "RM_cost": "0", "raw_material": "H<sub>2</sub>O", "specific_weight": "1"}, {"bases": [{"g_100g": "5", "v_100v": "11.51", "ml_100g": "5.000", "ml_1000ml": "115.10", "formula_cost": "0.0000"}, {"g_100g": "40", "v_100v": "55.26", "ml_100g": "37.383", "ml_1000ml": "552.60", "formula_cost": "0.1094"}], "RM_cost": "1.85", "raw_material": "Binder", "specific_weight": "1.07"}, {"bases": [{"g_100g": "25", "v_100v": "54.21", "ml_100g": "23.364", "ml_1000ml": "542.10", "formula_cost": "0.1073"}, {"g_100g": "20", "v_100v": "43.04", "ml_100g": "18.692", "ml_1000ml": "430.40", "formula_cost": "0.0852"}], "RM_cost": "3.25", "raw_material": "TiO<sub>2</sub>", "specific_weight": "3.8"}]}		0
86	2018-11-06 09:51:19.568604+01	test 2 basi	{"data": [{"bases": [{"g_100g": "7", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "1.6332"}, {"g_100g": "7", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "1.6332"}], "RM_cost": "7", "raw_material": "H<sub>2</sub>O", "specific_weight": "7"}, {"bases": [{"g_100g": "7", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "1.6332"}, {"g_100g": "7", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "1.6332"}], "RM_cost": "7", "raw_material": "Binder", "specific_weight": "7"}, {"bases": [{"g_100g": "7", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "1.6332"}, {"g_100g": "7", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "1.6332"}], "RM_cost": "7", "raw_material": "TiO<sub>2</sub>", "specific_weight": "7"}]}		0
90	2018-11-06 16:33:25.765823+01	test	{"data": [{"bases": [{"g_100g": "8", "v_100v": "8.27", "ml_100g": "1.000", "ml_1000ml": "82.70", "formula_cost": "0.5293"}, {"g_100g": "9", "v_100v": "39.13", "ml_100g": "1.125", "ml_1000ml": "391.30", "formula_cost": "2.5043"}, {"g_100g": "10", "v_100v": "39.86", "ml_100g": "1.250", "ml_1000ml": "398.60", "formula_cost": "2.5510"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "0.75", "ml_100g": "0.091", "ml_1000ml": "7.50", "formula_cost": "0.5280"}, {"g_100g": "11", "v_100v": "4.35", "ml_100g": "0.125", "ml_1000ml": "43.50", "formula_cost": "3.0624"}, {"g_100g": "12", "v_100v": "4.34", "ml_100g": "0.136", "ml_1000ml": "43.40", "formula_cost": "3.0554"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "88"}, {"bases": [{"g_100g": "88", "v_100v": "90.98", "ml_100g": "11.000", "ml_1000ml": "909.80", "formula_cost": "5.8227"}, {"g_100g": "13", "v_100v": "56.52", "ml_100g": "1.625", "ml_1000ml": "565.20", "formula_cost": "3.6173"}, {"g_100g": "14", "v_100v": "55.80", "ml_100g": "1.750", "ml_1000ml": "558.00", "formula_cost": "3.5712"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}]}		0
96	2018-11-07 13:01:48.432063+01	test 4rm2b	{"data": [{"bases": [{"g_100g": "8", "v_100v": "25.00", "ml_100g": "1.000", "ml_1000ml": "250.00", "formula_cost": "1.6000"}, {"g_100g": "9", "v_100v": "18.75", "ml_100g": "1.125", "ml_1000ml": "187.50", "formula_cost": "1.2000"}, {"g_100g": "10", "v_100v": "19.23", "ml_100g": "1.250", "ml_1000ml": "192.30", "formula_cost": "1.2307"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "25.00", "ml_100g": "1.000", "ml_1000ml": "250.00", "formula_cost": "1.6000"}, {"g_100g": "11", "v_100v": "22.92", "ml_100g": "1.375", "ml_1000ml": "229.20", "formula_cost": "1.4669"}, {"g_100g": "12", "v_100v": "23.08", "ml_100g": "1.500", "ml_1000ml": "230.80", "formula_cost": "1.4771"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "25.00", "ml_100g": "1.000", "ml_1000ml": "250.00", "formula_cost": "1.6000"}, {"g_100g": "13", "v_100v": "27.08", "ml_100g": "1.625", "ml_1000ml": "270.80", "formula_cost": "1.7331"}, {"g_100g": "14", "v_100v": "26.92", "ml_100g": "1.750", "ml_1000ml": "269.20", "formula_cost": "1.7229"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "25.00", "ml_100g": "1.000", "ml_1000ml": "250.00", "formula_cost": "1.6000"}, {"g_100g": "15", "v_100v": "31.25", "ml_100g": "1.875", "ml_1000ml": "312.50", "formula_cost": "2.0000"}, {"g_100g": "16", "v_100v": "30.77", "ml_100g": "2.000", "ml_1000ml": "307.70", "formula_cost": "1.9693"}], "RM_cost": "8", "raw_material": "rm1", "specific_weight": "8"}]}		0
98	2018-11-07 14:35:58.437696+01	test 3rm3b	{"data": [{"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "9", "v_100v": "25.00", "ml_100g": "1.125", "ml_1000ml": "250.00", "formula_cost": "1.6000"}, {"g_100g": "10", "v_100v": "25.64", "ml_100g": "1.250", "ml_1000ml": "256.40", "formula_cost": "1.6410"}, {"g_100g": "11", "v_100v": "26.19", "ml_100g": "1.375", "ml_1000ml": "261.90", "formula_cost": "1.6762"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "12", "v_100v": "33.33", "ml_100g": "1.500", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "13", "v_100v": "33.33", "ml_100g": "1.625", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "14", "v_100v": "33.33", "ml_100g": "1.750", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "", "formula_cost": "2.1331"}, {"g_100g": "15", "v_100v": "41.67", "ml_100g": "1.875", "ml_1000ml": "416.70", "formula_cost": "2.6669"}, {"g_100g": "16", "v_100v": "41.03", "ml_100g": "2.000", "ml_1000ml": "410.30", "formula_cost": "2.6259"}, {"g_100g": "17", "v_100v": "40.48", "ml_100g": "2.125", "ml_1000ml": "404.80", "formula_cost": "2.5907"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}]}		0
99	2018-11-07 14:37:12.093046+01	test 3rm4b	{"data": [{"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "9", "v_100v": "23.08", "ml_100g": "1.125", "ml_1000ml": "230.80", "formula_cost": "1.4771"}, {"g_100g": "10", "v_100v": "23.81", "ml_100g": "1.250", "ml_1000ml": "238.10", "formula_cost": "1.5238"}, {"g_100g": "11", "v_100v": "24.44", "ml_100g": "1.375", "ml_1000ml": "244.40", "formula_cost": "1.5642"}, {"g_100g": "12", "v_100v": "25.00", "ml_100g": "1.500", "ml_1000ml": "250.00", "formula_cost": "1.6000"}], "RM_cost": "8", "raw_material": "H<sub>2</sub>O", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "13", "v_100v": "33.33", "ml_100g": "1.625", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "14", "v_100v": "33.33", "ml_100g": "1.750", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "15", "v_100v": "33.33", "ml_100g": "1.875", "ml_1000ml": "333.30", "formula_cost": "2.1331"}, {"g_100g": "16", "v_100v": "33.33", "ml_100g": "2.000", "ml_1000ml": "333.30", "formula_cost": "2.1331"}], "RM_cost": "8", "raw_material": "Binder", "specific_weight": "8"}, {"bases": [{"g_100g": "8", "v_100v": "33.33", "ml_100g": "1.000", "ml_1000ml": "", "formula_cost": ""}, {"g_100g": "17", "v_100v": "43.59", "ml_100g": "2.125", "ml_1000ml": "435.90", "formula_cost": "2.7898"}, {"g_100g": "18", "v_100v": "42.86", "ml_100g": "2.250", "ml_1000ml": "428.60", "formula_cost": "2.7430"}, {"g_100g": "19", "v_100v": "42.22", "ml_100g": "2.375", "ml_1000ml": "422.20", "formula_cost": "2.7021"}, {"g_100g": "20", "v_100v": "41.67", "ml_100g": "2.500", "ml_1000ml": "416.70", "formula_cost": "2.6669"}], "RM_cost": "8", "raw_material": "TiO<sub>2</sub>", "specific_weight": "8"}]}		0
100	2018-11-12 11:39:13.063043+01	ttt	{"data": [{"bases": [{"g_100g": "3"}, {"g_100g": "4"}], "RM_cost": "2", "raw_material": "H2O", "specific_weight": "1"}, {"bases": [{"g_100g": "7"}, {"g_100g": "8"}], "RM_cost": "6", "raw_material": "Binder", "specific_weight": "5"}, {"bases": [{"g_100g": "11"}, {"g_100g": "12"}], "RM_cost": "10", "raw_material": "TiO2", "specific_weight": "9"}]}		0
102	2018-11-22 17:21:20.569035+01	ggg	{"data": [{"bases": [{"g_100g": "5"}, {"g_100g": "6"}, {"g_100g": "2"}], "RM_cost": "4", "raw_material": "H2O", "specific_weight": "8"}, {"bases": [{"g_100g": "5"}, {"g_100g": "4"}, {"g_100g": "8"}], "RM_cost": "2", "raw_material": "Binder", "specific_weight": "1"}, {"bases": [{"g_100g": "2"}, {"g_100g": "4"}, {"g_100g": "7"}], "RM_cost": "2", "raw_material": "TiO2", "specific_weight": "6"}]}		0
\.


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.product_product_id_seq', 102, true);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: product_product_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_product
    ADD CONSTRAINT product_product_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_0e939a4f ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_e8701ad4 ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_8373b171 ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

